function timeAgo(ts) {
  if (!ts) return "never";
  const sec = Math.floor((Date.now() - ts) / 1000);
  if (sec < 60) return `${sec}s ago`;
  if (sec < 3600) return `${Math.floor(sec / 60)}m ago`;
  if (sec < 86400) return `${Math.floor(sec / 3600)}h ago`;
  return `${Math.floor(sec / 86400)}d ago`;
}

(async function () {
  const [{ allowlist = [] }, { stats = {}, lastSync, syncStatus }, { settings = {} }] =
    await Promise.all([
      chrome.runtime.sendMessage({ type: "GET_ALLOWLIST" }),
      chrome.runtime.sendMessage({ type: "GET_STATS" }),
      chrome.runtime.sendMessage({ type: "GET_SETTINGS" })
    ]);

  document.getElementById("domainCount").textContent = allowlist.length;

  const today = new Date().toDateString();
  const blocks = stats.lastReset === today ? (stats.blocksToday || 0) : 0;
  document.getElementById("blockCount").textContent = blocks;

  // Update status card based on sync state
  const dot = document.getElementById("statusDot");
  const title = document.getElementById("statusTitle");
  const text = document.getElementById("statusText");

  if (settings.syncEnabled) {
    if (syncStatus === "ok") {
      dot.style.background = "#22c55e";
      dot.style.boxShadow = "0 0 0 4px rgba(34, 197, 94, 0.15)";
      title.textContent = "Synced & protecting";
      text.textContent = `Last sync ${timeAgo(lastSync)}`;
    } else if (syncStatus === "error") {
      dot.style.background = "#f59e0b";
      dot.style.boxShadow = "0 0 0 4px rgba(245, 158, 11, 0.15)";
      title.textContent = "Sync issue";
      text.textContent = `Using cached list · last try ${timeAgo(lastSync)}`;
    } else {
      dot.style.background = "#6b7894";
      dot.style.boxShadow = "0 0 0 4px rgba(107, 120, 148, 0.15)";
      title.textContent = "Connecting…";
      text.textContent = "Sync configured, awaiting first response";
    }
  } else {
    title.textContent = "Local mode";
    text.textContent = "Sync off — managing allowlist locally.";
  }

  document.getElementById("manageBtn").addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
  });
})();
