# Domain Guard

Allowlist-only browser extension for affiliate teams. Employees can only navigate to and type/paste approved domains. Anything else is blocked or stripped — and now they can request access in one click when they hit a domain they need.

**Version:** 0.4.0 — adds in-page request access flow

---

## What's new in v0.4

- **Request access from the blocked page** — when an employee hits a blocked URL, they can submit an access request with an optional reason
- **Smart de-duplication** — if a request for the same domain is already pending, the extension reuses it instead of spamming the admin
- **Backend-aware UX** — if backend sync isn't configured, the request form gracefully tells the user

---

## What it does

1. **Navigation lock** — Any URL not on the allowlist redirects to a friendly "blocked" page. The original URL is captured and reported.
2. **Paste filter** — Pasting text containing a disallowed domain strips the domain and shows a toast.
3. **Type filter** — Typing a disallowed domain in any input/textarea/contenteditable and hitting Enter or blurring strips it automatically.
4. **Subdomain coverage** — Adding `example.com` also allows `www.example.com`, `app.example.com`, `cdn.example.com`, etc.
5. **Backend sync** — Allowlist is centrally managed. Each PC pulls the latest list every 5 minutes. Block events are reported to a central log.
6. **Request access (new)** — Employees can ask for blocked domains to be unblocked. Admin reviews from the dashboard and approves with one click.

---

## Install (development / unpacked)

1. Open Chrome → `chrome://extensions`
2. Toggle **Developer mode** on (top right)
3. Click **Load unpacked**, select the `domain-guard/` folder

---

## Setup (with backend sync)

1. Click the extension icon → **Manage allowlist**
2. In the **Backend sync** section:
   - Toggle sync **on**
   - **Backend URL**: e.g. `http://localhost:4000`
   - **API key**: paste the `EXTENSION_API_KEY` from your server `.env`
   - **Employee ID**: e.g. `sabbir@nexbit` (used for per-employee block reports + access requests)
3. Click **Test connection** → should show ✓
4. Click **Save settings**

---

## Test the request flow

1. Configure backend sync (above)
2. Visit a domain not on your allowlist → blocked page appears
3. Click **Need access to this site? ▾** → form expands
4. Type a reason (optional) → click **Submit request**
5. Open the admin panel → **Access requests** tab → see your request
6. Click **Approve** → domain added to allowlist
7. Within 5 minutes the extension auto-syncs and the domain works

---

## Architecture

```
┌─────────────────────────────────────────┐
│ background.js (service worker)          │
│  • chrome.storage allowlist & settings  │
│  • Builds DNR rules dynamically         │
│  • chrome.alarms → 5-min sync           │
│  • Reports block events                 │
│  • Submits access requests (new in 0.4) │
└──────────┬──────────────────────────────┘
           │
           ├─ declarativeNetRequest (block + allow rules)
           ├─ fetch GET  /api/v1/allowlist        (sync)
           ├─ fetch POST /api/v1/events           (block events)
           └─ fetch POST /api/v1/access-requests  (request access)

content.js → strips disallowed domains from inputs
blocked.html → "Request access" form (new in 0.4)
```

---

## Roadmap

### ✅ v0.1 — Browser layer
### ✅ v0.2 — Backend sync
### ✅ v0.3 — Polished Next.js admin
### ✅ v0.4 — Request access workflow + per-employee deep-dive

### v0.5 — Multiple allowlist profiles
- Sales / QA / engineering teams get different lists
- Schema migration in backend (Allowlist already supports `name` field)

### v0.6 — Force install via Chrome Enterprise policy
- Pre-configure backend URL + API key via policy registry
- Lock the extension so employees can't disable it

### v1.0 — System-wide layer
- Electron tray app: local DNS allowlist + clipboard monitor
- Closes the "open Edge/Firefox" bypass

---

## File structure

```
domain-guard/
├── manifest.json          MV3 manifest (v0.4.0)
├── background.js          Service worker — rules + storage + sync + requests
├── content.js             Paste/blur/Enter filter
├── popup.html/css/js      Toolbar popup with sync status
├── options.html/css/js    Settings + allowlist CRUD
├── blocked.html           Block landing page (with request access form)
├── blocked.js             Block page logic + request submission
├── icons/                 16/48/128 icons
└── README.md
```

---

Built for NeXbit LTD · Brand: `#29AAE1` cyan / `#0E1C42` navy
