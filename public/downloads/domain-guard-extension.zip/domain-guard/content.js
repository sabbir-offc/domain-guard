// Domain Guard - Content Script
// Watches inputs/textareas/contenteditable for non-allowlisted domains
// and strips them on paste, blur, or Enter.

(function () {
  let allowlist = [];

  // Load allowlist
  chrome.storage.local.get("allowlist", ({ allowlist: list }) => {
    allowlist = Array.isArray(list) ? list : [];
  });

  // Live updates
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.allowlist) {
      allowlist = changes.allowlist.newValue || [];
    }
  });

  function isDomainAllowed(host) {
    if (!host) return true;
    host = host.toLowerCase();
    return allowlist.some(d => host === d || host.endsWith("." + d));
  }

  // Match URLs and bare domains. Captures things like:
  //   https://abc.com/path  |  abc.com  |  www.abc.com/foo?x=1
  const DOMAIN_RE = /\b((?:https?:\/\/)?(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,})(?:\/[^\s]*)?/gi;

  function filterText(text) {
    let blocked = false;
    let firstBlockedDomain = null;
    const cleaned = text.replace(DOMAIN_RE, (match) => {
      const host = match.replace(/^https?:\/\//i, "").split(/[\/\?#]/)[0];
      // Skip if it doesn't actually look like a domain (e.g., "node.js" in prose)
      if (!/\.[a-z]{2,}$/i.test(host)) return match;
      if (isDomainAllowed(host)) return match;
      blocked = true;
      if (!firstBlockedDomain) firstBlockedDomain = host.toLowerCase();
      return "[blocked]";
    });
    return { cleaned, blocked, domain: firstBlockedDomain };
  }

  function reportBlock(subtype, domain) {
    try {
      chrome.runtime.sendMessage({
        type: "RECORD_INPUT_BLOCK",
        subtype,
        domain
      });
    } catch (_) { /* ignore */ }
  }

  // ---------- Paste handler ----------
  document.addEventListener("paste", (e) => {
    const text = e.clipboardData?.getData("text");
    if (!text) return;
    const { cleaned, blocked, domain } = filterText(text);
    if (!blocked) return;

    e.preventDefault();
    e.stopPropagation();

    // Insert cleaned text at cursor. execCommand is deprecated but still
    // the most reliable cross-site way to programmatically insert text
    // that respects undo history.
    try {
      document.execCommand("insertText", false, cleaned);
    } catch (_) {
      const el = document.activeElement;
      if (el && "value" in el) {
        const start = el.selectionStart ?? el.value.length;
        const end = el.selectionEnd ?? el.value.length;
        el.value = el.value.slice(0, start) + cleaned + el.value.slice(end);
      }
    }

    showToast("Blocked domain removed from pasted text");
    reportBlock("paste", domain);
  }, true);

  // ---------- Blur handler (catch typed domains) ----------
  document.addEventListener("blur", (e) => {
    const el = e.target;
    if (!el || !el.tagName) return;
    const tag = el.tagName;
    const isText = tag === "INPUT" || tag === "TEXTAREA" || el.isContentEditable;
    if (!isText) return;

    const value = "value" in el ? el.value : el.textContent;
    if (!value) return;

    const { cleaned, blocked, domain } = filterText(value);
    if (!blocked) return;

    if ("value" in el) {
      el.value = cleaned;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      el.textContent = cleaned;
    }

    showToast("Blocked domain removed from input");
    reportBlock("input", domain);
  }, true);

  // ---------- Enter key (instant feedback in chat-style inputs) ----------
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Enter") return;
    const el = e.target;
    if (!el || !el.tagName) return;
    const tag = el.tagName;
    const isText = tag === "INPUT" || tag === "TEXTAREA" || el.isContentEditable;
    if (!isText) return;

    const value = "value" in el ? el.value : el.textContent;
    if (!value) return;

    const { cleaned, blocked, domain } = filterText(value);
    if (!blocked) return;

    e.preventDefault();
    e.stopPropagation();
    if ("value" in el) {
      el.value = cleaned;
    } else {
      el.textContent = cleaned;
    }
    showToast("Blocked domain — message not sent");
    reportBlock("input", domain);
  }, true);

  // ---------- Toast UI ----------
  let toastEl = null;
  let toastTimer = null;
  function showToast(msg) {
    if (!document.body) return;
    if (toastEl) toastEl.remove();
    toastEl = document.createElement("div");
    toastEl.textContent = msg;
    Object.assign(toastEl.style, {
      position: "fixed",
      bottom: "24px",
      right: "24px",
      background: "#0E1C42",
      color: "#fff",
      padding: "12px 18px",
      borderRadius: "8px",
      fontFamily: "system-ui, -apple-system, sans-serif",
      fontSize: "14px",
      fontWeight: "500",
      boxShadow: "0 8px 28px rgba(0,0,0,0.25)",
      zIndex: "2147483647",
      borderLeft: "4px solid #29AAE1",
      pointerEvents: "none",
      maxWidth: "320px"
    });
    document.body.appendChild(toastEl);
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toastEl?.remove();
      toastEl = null;
    }, 2800);
  }
})();
