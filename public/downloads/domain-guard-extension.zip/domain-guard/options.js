const $ = (id) => document.getElementById(id);

let allowlist = [];
let settings = { syncEnabled: false, backendUrl: "", apiKey: "", employeeId: "" };

function normalize(d) {
  return String(d || "")
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//, "")
    .split("/")[0];
}

function isValid(d) {
  return /^[a-z0-9.-]+\.[a-z]{2,}$/.test(d) && !d.startsWith(".") && !d.endsWith(".");
}

function timeAgo(ts) {
  if (!ts) return "never";
  const sec = Math.floor((Date.now() - ts) / 1000);
  if (sec < 60) return `${sec}s ago`;
  if (sec < 3600) return `${Math.floor(sec / 60)}m ago`;
  if (sec < 86400) return `${Math.floor(sec / 3600)}h ago`;
  return `${Math.floor(sec / 86400)}d ago`;
}

// ---------- Load ----------

async function load() {
  const [{ allowlist: list = [] }, { settings: s }] = await Promise.all([
    chrome.runtime.sendMessage({ type: "GET_ALLOWLIST" }),
    chrome.runtime.sendMessage({ type: "GET_SETTINGS" })
  ]);
  allowlist = list;
  settings = s || settings;

  $("syncToggle").checked = !!settings.syncEnabled;
  $("backendUrl").value = settings.backendUrl || "";
  $("apiKey").value = settings.apiKey || "";
  $("employeeId").value = settings.employeeId || "";

  applySyncMode();
  await refreshSyncStatus();
  render();
}

async function refreshSyncStatus() {
  if (!settings.syncEnabled) {
    $("syncStatus").hidden = true;
    return;
  }
  const data = await chrome.storage.local.get(["lastSync", "syncStatus", "lastSyncError"]);
  const el = $("syncStatus");
  el.hidden = false;
  el.className = "sync-status";

  if (!data.lastSync) {
    el.classList.add("idle");
    el.innerHTML = `<span class="dot"></span> Waiting for first sync…`;
  } else if (data.syncStatus === "ok") {
    el.classList.add("ok");
    el.innerHTML = `<span class="dot"></span> Synced ${timeAgo(data.lastSync)} · ${allowlist.length} domains`;
  } else {
    el.classList.add("err");
    el.innerHTML = `<span class="dot"></span> Sync failed ${timeAgo(data.lastSync)}: ${data.lastSyncError || "unknown error"}`;
  }
}

function applySyncMode() {
  const synced = settings.syncEnabled;
  $("syncBanner").hidden = !synced;

  // Disable local editing when sync is on
  $("newDomain").disabled = synced;
  $("addBtn").disabled = synced;
  $("bulkText").disabled = synced;
  $("importBtn").disabled = synced;

  // Hide remove buttons when synced
  document.querySelectorAll("#domainList li button").forEach(b => b.disabled = synced);
}

// ---------- Render allowlist ----------

function render() {
  $("count").textContent = `${allowlist.length} domain${allowlist.length === 1 ? "" : "s"}`;
  const filter = ($("search").value || "").toLowerCase().trim();
  const list = $("domainList");
  list.innerHTML = "";

  const filtered = allowlist.filter(d => !filter || d.includes(filter));
  $("emptyState").hidden = filtered.length > 0 || allowlist.length === 0;

  filtered.slice().sort().forEach((d) => {
    const li = document.createElement("li");
    const span = document.createElement("span");
    span.textContent = d;
    const btn = document.createElement("button");
    btn.textContent = "×";
    btn.title = `Remove ${d}`;
    btn.disabled = settings.syncEnabled;
    btn.addEventListener("click", async () => {
      if (settings.syncEnabled) return;
      allowlist = allowlist.filter(x => x !== d);
      await chrome.runtime.sendMessage({ type: "SET_ALLOWLIST", allowlist });
      render();
      toast(`Removed ${d}`);
    });
    li.append(span, btn);
    list.append(li);
  });
}

// ---------- Allowlist edits ----------

async function addDomain() {
  if (settings.syncEnabled) return;
  const d = normalize($("newDomain").value);
  if (!d) return;
  if (!isValid(d)) return toast("That doesn't look like a valid domain");
  if (allowlist.includes(d)) return toast(`${d} is already on the list`);

  allowlist.push(d);
  await chrome.runtime.sendMessage({ type: "SET_ALLOWLIST", allowlist });
  $("newDomain").value = "";
  render();
  toast(`Added ${d}`);
}

async function bulkImport() {
  if (settings.syncEnabled) return;
  const raw = $("bulkText").value;
  if (!raw.trim()) return;
  const lines = raw.split(/[\n,;\s]+/).map(normalize).filter(Boolean);
  const valid = [...new Set(lines.filter(isValid))];
  const invalid = lines.length - valid.length;

  if (valid.length === 0) return toast("No valid domains found");
  if (!confirm(`Replace allowlist with ${valid.length} domains?${invalid ? ` (${invalid} invalid skipped)` : ""}`)) return;

  allowlist = valid;
  await chrome.runtime.sendMessage({ type: "SET_ALLOWLIST", allowlist });
  $("bulkText").value = "";
  render();
  toast(`Imported ${valid.length} domains`);
}

function exportList() {
  $("bulkText").value = allowlist.slice().sort().join("\n");
  toast("Exported to text area");
}

// ---------- Settings ----------

async function saveSettings() {
  settings = {
    syncEnabled: $("syncToggle").checked,
    backendUrl: $("backendUrl").value.trim(),
    apiKey: $("apiKey").value.trim(),
    employeeId: $("employeeId").value.trim()
  };
  await chrome.runtime.sendMessage({ type: "SET_SETTINGS", settings });
  applySyncMode();
  toast("Settings saved");

  // Trigger immediate sync if enabled
  if (settings.syncEnabled) {
    setTimeout(async () => {
      await chrome.runtime.sendMessage({ type: "TRIGGER_SYNC" });
      const { allowlist: list = [] } = await chrome.runtime.sendMessage({ type: "GET_ALLOWLIST" });
      allowlist = list;
      render();
      await refreshSyncStatus();
    }, 200);
  } else {
    $("syncStatus").hidden = true;
  }
}

async function testConnection() {
  const url = $("backendUrl").value.trim().replace(/\/+$/, "");
  const key = $("apiKey").value.trim();
  if (!url || !key) return toast("Enter URL and API key first");

  $("testBtn").disabled = true;
  $("testBtn").textContent = "Testing…";
  try {
    const res = await fetch(url + "/api/v1/allowlist", {
      headers: { "x-api-key": key }
    });
    if (!res.ok) throw new Error("HTTP " + res.status);
    const data = await res.json();
    toast(`✓ Connected — ${data.domains?.length || 0} domains on server`);
  } catch (e) {
    toast(`✗ Connection failed: ${e.message}`);
  } finally {
    $("testBtn").disabled = false;
    $("testBtn").textContent = "Test connection";
  }
}

// ---------- Toast ----------

let toastTimer;
function toast(msg) {
  const el = $("toast");
  el.textContent = msg;
  el.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (el.hidden = true), 2400);
}

// ---------- Wire up ----------

$("addBtn").addEventListener("click", addDomain);
$("newDomain").addEventListener("keydown", (e) => { if (e.key === "Enter") addDomain(); });
$("search").addEventListener("input", render);
$("importBtn").addEventListener("click", bulkImport);
$("exportBtn").addEventListener("click", exportList);
$("saveSettingsBtn").addEventListener("click", saveSettings);
$("testBtn").addEventListener("click", testConnection);
$("syncToggle").addEventListener("change", () => {
  // Live preview of sync mode (locks UI immediately)
  settings.syncEnabled = $("syncToggle").checked;
  applySyncMode();
});

// Refresh sync status every 30s while page is open
setInterval(() => {
  if (settings.syncEnabled) refreshSyncStatus();
}, 30000);

load();
