const $ = (id) => document.getElementById(id);

// Show the blocked URL
const params = new URLSearchParams(location.search);
const blocked = params.get("url") || document.referrer || "";
const blockedDisplay = blocked || "Unknown";
$("blockedUrl").textContent = blockedDisplay;

let blockedDomain = "";
try { blockedDomain = new URL(blocked).hostname.toLowerCase(); } catch (_) {}

// Notify background to record the block + report to backend
if (blocked) {
  chrome.runtime.sendMessage({ type: "RECORD_NAV_BLOCK", url: blocked }).catch(() => {});
}

// ---------- Action buttons ----------

$("backBtn").addEventListener("click", () => {
  if (history.length > 1) history.back();
  else location.href = "https://google.com";
});

$("googleBtn").addEventListener("click", () => {
  location.href = "https://google.com";
});

// ---------- Request access ----------

const section = $("requestSection");
const toggle = $("requestToggle");
const form = $("requestForm");
const reasonInput = $("reasonInput");
const submitBtn = $("submitRequestBtn");
const resultEl = $("requestResult");
const disabledEl = $("requestDisabled");

toggle.addEventListener("click", () => {
  section.classList.toggle("open");
  if (section.classList.contains("open")) {
    setTimeout(() => reasonInput.focus(), 50);
  }
});

// Hide the form entirely if we don't have a domain to ask about
if (!blockedDomain) {
  section.style.display = "none";
}

function showResult(kind, message) {
  resultEl.className = "request-result show " + kind;
  resultEl.textContent = message;
}

async function checkSyncReady() {
  try {
    const { settings } = await chrome.runtime.sendMessage({ type: "GET_SETTINGS" });
    return !!(settings?.syncEnabled && settings?.backendUrl && settings?.apiKey);
  } catch (_) {
    return false;
  }
}

submitBtn.addEventListener("click", async () => {
  if (!blockedDomain) return;

  const ready = await checkSyncReady();
  if (!ready) {
    form.style.display = "none";
    disabledEl.style.display = "block";
    return;
  }

  submitBtn.disabled = true;
  submitBtn.textContent = "Submitting…";

  try {
    const res = await chrome.runtime.sendMessage({
      type: "REQUEST_ACCESS",
      domain: blockedDomain,
      url: blocked,
      reason: reasonInput.value.trim()
    });

    if (!res || !res.ok) {
      showResult("error", "Couldn't submit: " + (res?.error || "unknown error"));
      submitBtn.disabled = false;
      submitBtn.textContent = "Submit request";
      return;
    }

    if (res.duplicate) {
      showResult(
        "duplicate",
        "You already have a pending request for this domain. Your admin will review it."
      );
    } else {
      showResult(
        "success",
        "Request submitted! Your admin has been notified — once approved, this domain will work within 5 minutes."
      );
    }

    // Hide the form, leave the result visible
    form.style.display = "none";
    toggle.style.display = "none";
  } catch (e) {
    showResult("error", "Couldn't submit: " + (e.message || "unknown error"));
    submitBtn.disabled = false;
    submitBtn.textContent = "Submit request";
  }
});
