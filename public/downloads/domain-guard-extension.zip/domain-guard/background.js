// Domain Guard - Service Worker (v0.2)
// - Manages allowlist storage and dynamic block/allow rules
// - Periodically syncs allowlist from backend (when configured)
// - Reports block events to backend (fire-and-forget)

const BLOCK_RULE_ID = 1;
const ALLOW_RULE_BASE = 1000;
const SYNC_ALARM = "syncAllowlist";
const SYNC_INTERVAL_MIN = 5;

// Default allowlist - seeded on first install only
const DEFAULT_ALLOWLIST = [
  // Google ecosystem
  "google.com", "googleapis.com", "googleusercontent.com", "gstatic.com",
  "youtube.com", "ytimg.com", "ggpht.com",
  // Meta
  "facebook.com", "fbcdn.net", "instagram.com", "cdninstagram.com", "whatsapp.com",
  // Microsoft
  "microsoft.com", "office.com", "live.com", "outlook.com",
  // AI tools
  "chatgpt.com", "openai.com", "claude.ai", "anthropic.com",
  "deepseek.com", "perplexity.ai", "x.ai", "huggingface.co",
  "mistral.ai", "character.ai", "poe.com", "copilot.microsoft.com",
  // Productivity
  "notion.so", "slack.com", "dropbox.com", "figma.com", "canva.com",
  "zoom.us", "linkedin.com",
  // Dev
  "github.com", "gitlab.com", "stackoverflow.com", "npmjs.com",
  // NeXbit affiliate offers
  "creditscore.llc", "checkyourscore.cash", "creditfast.credit",
  "creditscoreusa.org", "publicreport.me", "nexbithr.it.com",
  // Real estate
  "zillow.com", "realtor.com", "apartments.com", "redfin.com", "trulia.com"
];

// ---------- Storage helpers ----------

async function getAllowlist() {
  const { allowlist } = await chrome.storage.local.get("allowlist");
  return Array.isArray(allowlist) ? allowlist : [];
}

async function setAllowlist(list) {
  const cleaned = [...new Set(
    list
      .map(d => String(d).trim().toLowerCase())
      .map(d => d.replace(/^https?:\/\//, ""))
      .map(d => d.split("/")[0])
      .filter(d => /^[a-z0-9.-]+\.[a-z]{2,}$/.test(d))
  )];
  await chrome.storage.local.set({ allowlist: cleaned });
}

async function getSettings() {
  const { settings } = await chrome.storage.local.get("settings");
  return settings || {
    syncEnabled: false,
    backendUrl: "",
    apiKey: "",
    employeeId: ""
  };
}

async function getStats() {
  const { stats } = await chrome.storage.local.get("stats");
  return stats || { blocksToday: 0, lastReset: new Date().toDateString() };
}

async function incrementBlock() {
  const stats = await getStats();
  const today = new Date().toDateString();
  if (stats.lastReset !== today) {
    stats.blocksToday = 0;
    stats.lastReset = today;
  }
  stats.blocksToday += 1;
  await chrome.storage.local.set({ stats });
}

// ---------- Rule management (serialized + idempotent) ----------

let rebuildChain = Promise.resolve();
function rebuildRules() {
  rebuildChain = rebuildChain.then(_rebuildRules).catch((err) => {
    console.error("[Domain Guard] rebuildRules failed:", err);
  });
  return rebuildChain;
}

async function _rebuildRules() {
  const allowlist = await getAllowlist();

  const allowRules = allowlist.map((domain, i) => ({
    id: ALLOW_RULE_BASE + i,
    priority: 100,
    action: { type: "allow" },
    condition: {
      requestDomains: [domain],
      resourceTypes: ["main_frame", "sub_frame"]
    }
  }));

  // Block rule: redirect to blocked.html with original URL captured via regex
  const blockedUrl = chrome.runtime.getURL("blocked.html");
  const blockRule = {
    id: BLOCK_RULE_ID,
    priority: 1,
    action: {
      type: "redirect",
      redirect: {
        regexSubstitution: blockedUrl + "?url=\\0"
      }
    },
    condition: {
      regexFilter: "^https?://.*",
      resourceTypes: ["main_frame"]
    }
  };

  const addRules = [blockRule, ...allowRules];
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = [...new Set([
    ...existing.map(r => r.id),
    ...addRules.map(r => r.id)
  ])];

  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds,
    addRules
  });
}

// ---------- Backend sync ----------

async function syncAllowlist() {
  const settings = await getSettings();
  if (!settings.syncEnabled || !settings.backendUrl || !settings.apiKey) {
    return;
  }

  const url = settings.backendUrl.replace(/\/+$/, "") + "/api/v1/allowlist";

  try {
    const res = await fetch(url, {
      headers: { "x-api-key": settings.apiKey }
    });
    if (!res.ok) throw new Error("HTTP " + res.status);
    const data = await res.json();
    if (!Array.isArray(data.domains)) throw new Error("Invalid response");

    await setAllowlist(data.domains);
    await chrome.storage.local.set({
      lastSync: Date.now(),
      syncStatus: "ok",
      lastSyncError: null
    });
  } catch (e) {
    console.warn("[Domain Guard] Sync failed:", e.message);
    await chrome.storage.local.set({
      lastSync: Date.now(),
      syncStatus: "error",
      lastSyncError: e.message
    });
  }
}

async function reportEvent(event) {
  const settings = await getSettings();
  if (!settings.syncEnabled || !settings.backendUrl || !settings.apiKey) return;

  const url = settings.backendUrl.replace(/\/+$/, "") + "/api/v1/events";

  try {
    await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": settings.apiKey
      },
      body: JSON.stringify({
        ...event,
        employeeId: settings.employeeId || "unknown"
      })
    });
  } catch (_) {
    // silent fail — local stat still incremented
  }
}

async function submitAccessRequest({ domain, url, reason }) {
  const settings = await getSettings();
  if (!settings.syncEnabled || !settings.backendUrl || !settings.apiKey) {
    return { ok: false, error: "Backend sync not configured" };
  }

  const endpoint = settings.backendUrl.replace(/\/+$/, "") + "/api/v1/access-requests";

  try {
    const res = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": settings.apiKey
      },
      body: JSON.stringify({
        employeeId: settings.employeeId || "unknown",
        domain,
        url,
        reason: reason || ""
      })
    });

    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      return { ok: false, error: data.error || `HTTP ${res.status}` };
    }
    return { ok: true, ...data };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// ---------- Lifecycle ----------

chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === "install") {
    const existing = await getAllowlist();
    if (existing.length === 0) {
      await setAllowlist(DEFAULT_ALLOWLIST);
    }
  }
  await rebuildRules();

  // Set up periodic sync alarm
  chrome.alarms.create(SYNC_ALARM, {
    periodInMinutes: SYNC_INTERVAL_MIN,
    delayInMinutes: 0.1
  });
});

chrome.runtime.onStartup.addListener(async () => {
  await rebuildRules();
  syncAllowlist();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === SYNC_ALARM) syncAllowlist();
});

// Rebuild rules on local allowlist changes
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.allowlist) rebuildRules();
});

// ---------- Message handling ----------

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (msg.type === "GET_ALLOWLIST") {
      sendResponse({ allowlist: await getAllowlist() });
    } else if (msg.type === "SET_ALLOWLIST") {
      await setAllowlist(msg.allowlist);
      sendResponse({ ok: true });
    } else if (msg.type === "GET_SETTINGS") {
      sendResponse({ settings: await getSettings() });
    } else if (msg.type === "SET_SETTINGS") {
      await chrome.storage.local.set({ settings: msg.settings });
      if (msg.settings?.syncEnabled) syncAllowlist();
      sendResponse({ ok: true });
    } else if (msg.type === "TRIGGER_SYNC") {
      await syncAllowlist();
      const { lastSync, syncStatus, lastSyncError } = await chrome.storage.local.get([
        "lastSync", "syncStatus", "lastSyncError"
      ]);
      sendResponse({ lastSync, syncStatus, lastSyncError });
    } else if (msg.type === "GET_STATS") {
      const stats = await getStats();
      const sync = await chrome.storage.local.get(["lastSync", "syncStatus"]);
      sendResponse({ stats, ...sync });
    } else if (msg.type === "RECORD_INPUT_BLOCK") {
      await incrementBlock();
      reportEvent({
        type: msg.subtype || "input",
        domain: msg.domain,
        url: sender.tab?.url
      });
      sendResponse({ ok: true });
    } else if (msg.type === "RECORD_NAV_BLOCK") {
      await incrementBlock();
      let domain = "";
      try { domain = new URL(msg.url).hostname; } catch (_) {}
      reportEvent({
        type: "navigation",
        domain,
        url: msg.url
      });
      sendResponse({ ok: true });
    } else if (msg.type === "REQUEST_ACCESS") {
      const result = await submitAccessRequest({
        domain: msg.domain,
        url: msg.url,
        reason: msg.reason
      });
      sendResponse(result);
    }
  })();
  return true;
});
